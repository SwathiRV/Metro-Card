package com.geektrust.backend.utility;

public class Utility {
    
    public static void print(String message){
        System.out.println(message);
    }
}
