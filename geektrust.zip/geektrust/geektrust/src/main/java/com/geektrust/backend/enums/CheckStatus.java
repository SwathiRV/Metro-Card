package com.geektrust.backend.enums;

public enum CheckStatus {

    CHECK_IN,
    CHECK_OUT;
    
}
