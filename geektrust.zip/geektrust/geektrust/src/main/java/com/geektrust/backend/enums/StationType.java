package com.geektrust.backend.enums;

public enum StationType {
    CENTRAL, AIRPORT
}
