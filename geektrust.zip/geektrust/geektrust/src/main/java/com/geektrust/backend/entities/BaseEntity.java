package com.geektrust.backend.entities;

public class BaseEntity {
    
    protected String id;

    public String getId(){
        return id;
    }

}
